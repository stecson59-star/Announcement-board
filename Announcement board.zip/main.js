function postAnnouncement() {
    // Get input value
    let message = document.getElementById("messageInput").value;

    // Display it in output box
    document.getElementById("outputBox").innerText = message;
}